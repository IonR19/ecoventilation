import{S as s,i as t,s as a}from"../chunks/index-2a81514a.js";class o extends s{constructor(e){super(),t(this,e,null,null,a,{})}}export{o as default};
